Joe Canero
Assignment 6
CSC260/Dr. Pulimood

This program will allow you to manipulate sets of objects, specifically positive even integers.

Included with this assignment are two text files used to input data. You can choose to input set data only from the keyboard, only from the file, from both sources, or from none. If the user opts to input no elements, two elements will be inserted into the Set.

This program will also exercise its capabilities to perform set unions and intersections.

Union- the making of a new set that contains all elements in both sets, minus repeats

Intersection- the making of a new set that contains only the elements shared between both sets, minus repeats

To compile this program, simply type ‘make’.


//  Name: Joe Canero
//  Course: CSC260, Section 2
//  Semester: Fall 2012
//  Instructor: Dr. Monisha Pulimood
//  Assignment 2
//  Description: This file contains all of the function prototypes and constants for bowlingAlleyP.cpp
//  bowlingAlleyFns.h
//  Created by caneroj1 on 9/15/12.

#include <iostream>
#include <fstream>
#include <string>
//#include "bowlingAlleyFns.cpp"

using namespace std;

const int MAX_PLAYERS = 20;
const int MAX_GAMES = 10;


/*
Function: scoreCompute
**********************
inputs: throw1 & throw2
output: score for the game
PRECONDITION: the score for the specified game is able to be computed. it is able to be overwritten
POSTCONDITION: the score for the specified game is computed and returned.
*/

int scoreCompute (int&, int&);

/*
Function: calculateScore
**********************
inputs: int player & int game & the array of players and their games
output: none. the score returned from scoreCompute is placed into the position in the array specified by player and game
PRECONDITION: the player and game variables are valid
POSTCONDITION: the score is valid and is placed into the specified position of the array
 */

void calculateScore(int, int, int[][10]);

/*
 Function: displayScores
 **********************
 inputs: int player & int game & the array of players and their games
 outputs: none. the score for the specified player and game is output to the screen.
 PRECONDITION: the parameters passed in are valid.
 POSTCONDITION: the score for the specified player and game is output to the screen.
 */

void displayScores(int, int, int[][10]);

/*
 Function: fileIO
 **********************
 inputs: ifstream & ofstream objects
 output: none. opens the proper files
 PRECONDITION: the files aren't opened or they are opened to a different file and the user wants to change files.
 POSTCONDITION: the specified files are opened successfully.
 */

void fileIO(ifstream&, ofstream&);

/*
 Function: inputSuccess
 **********************
 inputs: int players & int games
 outputs: a boolean
 PRECONDITION: integers for the player number and game number is input
 POSTCONDITION: it is ensured the integers are valid
 */

bool inputSuccess(int&, int&);

/*
 Function: scoreComputeFromFile
 **********************
 inputs: int for how many players score will be computed, int for how many games will be computed for each player and the ifstream object
 outputs: the score for a specific game
 PRECONDITION: the integers passed in are valid and the file is open
 POSTCONDITION: score is computed for a game
 */

int scoreComputeFromFile(int&, int&, ifstream&);

/*
 Function: calculateScoreFromFile
 **********************
 inputs: throw1 & throw2 & the ifstream object & the multidimensional array
 outputs: none. the score for a specific game is calculated and placed in the array
 PRECONDITION: the ints passed in are valid
 POSTCONDITION: the score for a game is placed into an array
 */

void calculateScoreFromFile(int, int, int[][10], ifstream&);

/*
 Function: readFromF
  **********************
 inputs: the ifstream object and the multidimensional array
 output: none. the file is being read from
 PRECONDITION: the file is opened successfully
 POSTCONDITION: values for how many players and games for each will be computed. these values are passed into the calculateScoreFromFile function
 */

void readFromF(ifstream&, int[][10]);

/*
Function: inputSuccessFile
 **********************
 inputs: the values retrieved from readFromF: number of players and number of games
outputs: a boolean value that ensures the numbers of players and games is valid
PRECONDITION: files are opened successfully and the values of games and players are passed in to be checked
 POSTCONDITION: the integers are valid
*/

bool inputSuccessFile (int&, int&);

/*
Function: outputToFile
  **********************
 inputs: ofstream object & the multidimensional array
 outputs: none. the file is written
 PRECONDITION: the file is opened successfully
 POSTCONDITION: the contents of the multidimensional array are written to the output file successfully
 */

void outputToFile(ofstream&, int[][10]);

/*
 Function: outputToScreen
  **********************
 inputs: the multidimensional array
 outputs: none. the scores of players are output to the screen
 PRECONDITION: the scores are able to be output to the screen
 POSTCONDITION: the scores for all players with scores are output to screen
 */

void outputToScreen(int[][10]);
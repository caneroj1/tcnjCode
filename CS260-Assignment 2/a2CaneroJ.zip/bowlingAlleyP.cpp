//  Name: Joe Canero
//  Course: CSC260, Section 2
//  Semester: Fall 2012
//  Instructor: Dr. Monisha Pulimood
//  Assignment 2
//  Description: This program keeps accurate score for a bowling alley, allows for user input, is capable of reading and writing to files and formats data neatly.
//  bowlingAlleyP.cpp
//  Created by caneroj1 on 9/15/12.

#include "bowlingAlleyFns.h"

using namespace std;

int main()
{
    ifstream inFile; //file input object
    ofstream outFile;  //file output object
    int scoreCard [MAX_PLAYERS][MAX_GAMES];  //the multidimensional array for storing game scores for each player
    int player = 0;  //these variables for user input dictate which player and game will be accessed
    int game = 0;
    char userComm;  //char used for storing user input
    char computeScore = 'i'; //chars used for changing flow of program
    char displayScoresS = 'd';
    char fileInputs = 'f';
    char exitP = 'e';
    char readFile = 'r';
    char outputData = 'o';
    bool exit = false;
    bool input = false;
    
    for(int a = 0; a < MAX_PLAYERS; a++) //initializes each index of the array to -1. This is used for processing purposes
    {
        for(int b = 0; b < MAX_GAMES; b++)
        {
            scoreCard[a][b] = -1;
        }
    }
    
    //This is the main driver of the program. It is a loop where the user is able to input the commands for the operations the user desires executed
    //The loop closes when the user inputs the exit key
    
    cout << endl << "Welcome to the Droll Bowling Alley Scorekeeping Program." << endl << "********************************************************"<< endl <<endl;
    
    do
    {
        cout << "What would you like to do?" << endl << "Valid commands: (i)nput score, (d)isplay scores, set (f)iles for input and output, (r)ead from file for input, (o)utput all data to the file, or (e)xit."<< endl << "Input Command: ";
        cin >> userComm;
        cout << endl;
        
        if(userComm == computeScore) //this block computes score for a game
        {
            cout << "There are 20 players and 10 games per player." << endl;
            cout << "What is the player number? ";
            do //this code block checks if the input is a number
            {
                cin >> player;
                if(cin.fail())
                {
                    cin.clear();
                    cin.ignore(80, '\n');
                    cerr << "Please enter a number from 1 - 20." << endl;
                    input = false;
                }
                else
                    input = true;
            }while(!input);
            
            cout << endl;
            
            cout << "What is the game number? ";
            do //this code block checks if the input is a number
            {
                cin >> game;
                if(cin.fail())
                {
                    cin.clear();
                    cin.ignore(80, '\n');
                    cerr << "Please enter a number from 1 - 10." << endl;
                    input = false;
                }
                else
                    input = true;
            }while(!input);
            
            cout << endl;
            if(inputSuccess(player, game))
                calculateScore(player-1, game-1, scoreCard);
        }
        
        if(userComm == displayScoresS) //this displays the score of a specific game for a specific person
        {
            cout << "What is the player number? ";
            cin >> player;
            cout << endl;
            cout << "What is the game number? ";
            cin >> game;
            cout << endl;
            if(inputSuccess(player, game))
                displayScores(player-1, game-1, scoreCard);
        }
        
        if(userComm == fileInputs) //this will open files used for reading and writing
            fileIO(inFile, outFile);
        
        if(userComm == readFile) //this reads data from the file for how many games and players is specified by the user
            readFromF(inFile, scoreCard);
        
        if(userComm == outputData) //this outputs all data to the output file
            outputToFile(outFile, scoreCard);
        
        if(userComm == exitP) //this exits
        {
            outputToScreen(scoreCard);
            exit = true;
        }
        
    }while(!exit);
}
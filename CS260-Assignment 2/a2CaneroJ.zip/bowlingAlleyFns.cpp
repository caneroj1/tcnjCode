//  Name: Joe Canero
//  Course: CSC260, Section 2
//  Semester: Fall 2012
//  Instructor: Dr. Monisha Pulimood
//  Assignment 2
//  Description: This file contains all of the function definitions for bowlingAlleyP.cpp
//  bowlingAlleyFns.cpp
//  Created by caneroj1 on 9/15/12.

#include "bowlingAlleyFns.h"


using namespace std;

//this function computes the score of an individual frame
//if the throws involved in calculating the score for a frame overflow into the next frame,
//they are saved as reference parameters and passed in to the next frame calculation

int scoreCompute(int& throw1, int& throw2)
{
    bool input;
    int roll1 = 0;
    int roll2 = 0;
    int roll3 = 0;
    int frameS = 0;
    
    if(throw1 == -1) //no throw is passed in to this frame calculation
    {
        cout << "Enter your roll: ";
        do
        {
            //cin >> roll1;
            do //this code block checks if the input is a number
            {
                cin >> roll1;
                if(cin.fail())
                {
                    cin.clear();
                    cin.ignore(80, '\n');
                    cerr << "Please enter an appropriate number." << endl;
                    input = false;
                }
                else
                    input = true;
            }while(!input);
            
            if(roll1 > 10 || roll1 < 0) //checks if input does not violate the Laws of Bowling (too many pins or negative pins)
            {
                cout << "That is invalid. Please re-enter.";
                input = false;
            }
            else
                input = true;
        }while(!input);
    }
    else
        roll1 = throw1; //the throw passed in is stored as the first row
    
    if(roll1 < 10) //non-strike
    {
        if(throw2 == -1) //a second throw was not passed in
        {
            do
            {
                cout << "Enter your roll: ";
                //cin >> roll2;
                do //this code block checks if the input is a number
                {
                    cin >> roll2;
                    if(cin.fail())
                    {
                        cin.clear();
                        cin.ignore(80, '\n');
                        cerr << "Please enter an appropriate number." << endl;
                        input = false;
                    }
                    else
                        input = true;
                }while(!input);
                if((roll1 + roll2) > 10 || roll2 < 0) //checks if input does not violate the Laws of Bowling (too many pins or negative pins)
                {
                    cout << "That is invalid. Please re-enter.";
                    input = false;
                }
                else
                    input = true;
            }while(!input);
        }
        else
            roll2 = throw2; //if a second throw is passed in it is stores it as the second roll
        if (roll1 + roll2 < 10)
        {
            frameS = roll1 + roll2;
            throw1 = -1;
            throw2 = -1;
            return(frameS);
        }
        else if(roll1 + roll2 == 10) //a spare is achieved
        {
            do
            {
                cout << "Enter your roll: ";
                //cin >> roll3;
                do //this code block checks if the input is a number
                {
                    cin >> roll3;
                    if(cin.fail())
                    {
                        cin.clear();
                        cin.ignore(80, '\n');
                        cerr << "Please enter an appropriate number." << endl;
                        input = false;
                    }
                    else
                        input = true;
                }while(!input);
                if(roll3 > 10 || roll3 < 0) //checks if input does not violate the Laws of Bowling (too many pins or negative pins)
                {
                    cout << "That is invalid. Please re-enter.";
                    input = false;
                }
                else
                    input = true;
            }while(!input);
            
            frameS = roll1 + roll2 + roll3; //score calculation
            throw1 = roll3;
            throw2 = -1;
            return frameS;
        }
    }
    
    else if(roll1 == 10) //first throw is strike
    {
        if(throw2 == -1)
        {
            do
            {   cout << "Enter your roll: ";
                //cin >> roll2;
                do //this code block checks if the input is a number
                {
                    cin >> roll2;
                    if(cin.fail())
                    {
                        cin.clear();
                        cin.ignore(80, '\n');
                        cerr << "Please enter an appropriate number." << endl;
                        input = false;
                    }
                    else
                        input = true;
                }while(!input);
                if(roll2 > 10 || roll2 < 0) //checks if input does not violate the Laws of Bowling (too many pins or negative pins)
                {
                    cout << "That is invalid. Please re-enter.";
                    input = false;
                }
                else
                    input = true;
            }while(!input);
        }
        else
            roll2 = throw2;
        if(roll2 < 10)
        {
            do
            {
                cout << "Enter your roll: ";
                //cin >> roll3;
                do //this code block checks if the input is a number
                {
                    cin >> roll3;
                    if(cin.fail())
                    {
                        cin.clear();
                        cin.ignore(80, '\n');
                        cerr << "Please enter an appropriate number." << endl;
                        input = false;
                    }
                    else
                        input = true;
                }while(!input);
                if(roll2 + roll3 > 10 || roll3 < 0) //checks if input does not violate the Laws of Bowling (too many pins or negative pins)
                {
                    input = false;
                    cout << "That is invalid. Please re-enter.";
                }
                else
                    input = true;
            }while(!input);
            
            if(roll2 + roll3 < 10) //no spare
            {
                frameS = roll1 + roll2 + roll3;
                throw1 = roll2;
                throw2 = roll3;
                return frameS;
            }
            else if(roll2 + roll3 == 10) //a spare
            {
                frameS = roll1 + roll2 + roll3;
                throw1 = roll2;
                throw2 = roll3;
                return frameS;
            }
        }
        else if(roll2 == 10) //roll2 is strike
        {
            do
            {
                cout << "Enter your roll: ";
                // cin >> roll3;
                do //this code block checks if the input is a number
                {
                    cin >> roll3;
                    if(cin.fail())
                    {
                        cin.clear();
                        cin.ignore(80, '\n');
                        cerr << "Please enter an appropriate number." << endl;
                        input = false;
                    }
                    else
                        input = true;
                }while(!input);
                if(roll3 > 10 || roll3 < 0) //checks if input does not violate the Laws of Bowling (too many pins or negative pins)
                {
                    input = false;
                    cout << "That is invalid. Please re-enter.";
                }
                else
                    input = true;
            }while(!input);
            
            if(roll3 < 10) //no strike
            {
                frameS = roll1 + roll2 + roll3;
                throw1 = roll2;
                throw2 = roll3;
                return frameS;
            }
            else if (roll3 == 10) //strike
            {
                frameS = roll1 + roll2 + roll3;
                throw1 = roll2;
                throw2 = roll3;
                return frameS;
            }
        }
    }
}

//this function calculates the score for the specified game for the specified player
//the function contains a loop that dictates the current frame

void calculateScore(int player, int game, int scoreCard[][10])
{
    int throw1 = -1;
    int throw2 = -1;
    int frameScore[10];
    int totalScore = 0;
    int i = 0;
    
    while(i < 10)
    {
        frameScore[i] = scoreCompute(throw1, throw2);
        cout << "Your score for frame " << i+1 <<" is " << frameScore[i] << ".";
        totalScore += frameScore[i];
        cout << " Your total score is " << totalScore << "." << endl;
        i++;
    }
    
    cout << "Score of " << totalScore << " saved to player " << player+1 << " for game " << game+1 << endl;
    scoreCard[player][game] = totalScore;
}

//this function displays the score for player (b) and game (c)

void displayScores(int b, int c, int scoreCard[][10])
{
    if(scoreCard[b][c] != -1 && scoreCard[b][c] >= 0 && scoreCard[b][c] <= 300)
        cout << "********** Player " << b+1 << " Game " << c+1 << ": " << scoreCard[b][c] << " **********" << endl << endl;
    else
        cout << "********** ERROR: That game has not been played yet. **********" << endl << endl;
}

//this function opens the files the user inputs and the fstream objects are reference parameters

void fileIO(ifstream& inFile, ofstream& outFile)
{
    string inFileName = "";
    string outFileName = "";
    bool iWork;
    char failChar = 's';
    cout << "What file would you like to read from? If you do not want to read from a file, enter 's'." << endl;
    do
    {
        cin >> inFileName;
        inFile.open(inFileName.c_str());
        if(inFile.fail())
        {
            inFile.clear();
            cerr << "The file opening process failed. Re-enter file name: " << endl << endl;
            cin.ignore(80,'\n');
            iWork = false;
        }
        else
            iWork = true;
    } while(!iWork && inFileName[0] != failChar);
    
    cout << "What file would you like to write to?" << endl;
    
    do
    {
        cin >> outFileName;
        outFile.open(outFileName.c_str());
        if(outFile.fail())
        {
            outFile.clear();
            cerr << "The file opening process failed. Re-enter file name: " << endl << endl;
            cin.ignore(80,'\n');
            iWork = false;
        }
        else
            iWork = true;
        
    } while(!iWork);
    cout << "********** File opening process was successful! **********" << endl << endl;
}

//checks if the integers are within the valid bounds of the program (20 players and 10 games)

bool inputSuccess (int& player, int& game)
{
    bool input = true;
    if(player < 1 || player > 20)
    {
        do {
            cout << "Player input invalid. Input must be in the range of 1 - 20. Please re-enter." << endl;
            do //this code block checks if the input is a number
            {
                cin >> player;
                if(cin.fail())
                {
                    cin.clear();
                    cin.ignore(80, '\n');
                    cerr << "Please enter a number from 1 - 20." << endl;
                    input = false;
                }
                else
                    input = true;
            }while(!input);
            
            if(player < 1 || player > 20)
            {
                input = false;
            }
            else
                input = true;
            
        }while (!input);
    }
    
    if(game < 1 || game > 10)
    {
        do {
            
            cout << "Game input invalid. Input must be in the range of 1 - 10. Please re-enter." << endl;
            do //this code block checks if the input is a number
            {
                cin >> game;
                if(cin.fail())
                {
                    cin.clear();
                    cin.ignore(80, '\n');
                    cerr << "Please enter a number from 1 - 20." << endl;
                    input = false;
                }
                else
                    input = true;
            }while(!input);
            
            if(game < 1 || game > 10)
            {
                input = false;
            }
            else
                input = true;
            
        } while (!input);
    }
    return input;
}

//checks if the input is within the valid bounds when reading from a file (at least one player and at least one game for the player(s))

bool inputSuccessFile (int& loopPlayers, int& loopGames)
{
    bool input = true;
    if(loopPlayers < 1 || loopPlayers > 20)
    {
        do {
            cout << "Input invalid. Please re-enter." << endl;
            cin >> loopPlayers;
            
            if(loopPlayers < 1 || loopPlayers > 20)
            {
                cout << "Input invalid. Please re-enter." << endl;
                input = false;
            }
            else
                input = true;
            
        }while (!input);
    }
    
    if(loopGames < 1 || loopGames > 10)
    {
        do {
            cout << "Input invalid. Please re-enter." << endl;
            cin >> loopGames;
            
            if(loopGames < 1 || loopGames > 10)
            {
                cout << "Input invalid. Please re-enter." << endl;
                input = false;
            }
            else
                input = true;
            
        } while (!input);
    }
    return input;
}

//receives input for the number of players and games that will be read and passes them into the calculateScoreFromFile

void readFromF(ifstream& inFile, int scoreCard[][10])
{
    int loopPlayers = 0;
    int loopGames = 0;
    
    if(inFile.is_open())
    {
        cout << "How many players will you read for? Please enter a value between 1 and 20." << endl;
        cin >> loopPlayers;
        cout << "How many games will be read for each player? Please enter a value between 1 and 10" << endl;
        cin >> loopGames;
        if(inputSuccessFile(loopPlayers, loopGames))
            calculateScoreFromFile(loopPlayers, loopGames, scoreCard, inFile);
    }
    else
        cout << "********* You have not opened a file yet! *********" << endl << "You must set (f)iles for input and output." << endl << endl;
    
}

//this method loops through the number of players and games for each and calculates the score for them.

void calculateScoreFromFile(int totPlayer, int totGame, int scoreCard[][10], ifstream& inFile)
{
    int throw1 = -1;
    int throw2 = -1;
    int frameScore[10];
    int totalScore = 0;
    int i = 0;
    int gamesCo = totGame;
    
    for(int playCount = 0; playCount < totPlayer; playCount++)
    {
        for(int gameCount = 0; gameCount < totGame; gameCount++)
        {
            if(scoreCard[playCount][gameCount] == -1)
            {
                while(i < 10)
                {
                    frameScore[i] = scoreComputeFromFile(throw1, throw2, inFile);
                    totalScore += frameScore[i];
                    i++;
                }
                cout << "Score of " << totalScore << " saved to player " << playCount+1 << " for game " << gameCount+1 << endl;
                scoreCard[playCount][gameCount] = totalScore;
                throw1 = -1;
                throw2 = -1;
                i = 0;
                totalScore = 0;
            }
            else if(totGame < 9)
                totGame +=1;
        }
        totGame = gamesCo;
    }
}

//this function computes score the same way as scoreCompute but it reads from a file instead of using cin

int scoreComputeFromFile(int& throw1, int& throw2, ifstream& inFile)
{
    bool input;
    int roll1 = 0;
    int roll2 = 0;
    int roll3 = 0;
    int frameS = 0;
    
    if(throw1 == -1)
    {
        do
        {
            do //this code block checks if the input is a number
            {
                inFile >> roll1;
                if(cin.fail())
                {
                    cin.clear();
                    cin.ignore(80, '\n');
                    input = false;
                }
                else
                    input = true;
            }while(!input);
            if(roll1 > 10 || roll1 < 0)
            {
                cout << "That is invalid. Please re-enter.";
                input = false;
            }
            else
                input = true;
        }while(!input);
    }
    else
        roll1 = throw1;
    
    if(roll1 < 10)
    {
        if(throw2 == -1)
        {
            do
            {
                do //this code block checks if the input is a number
                {
                    inFile >> roll2;
                    if(cin.fail())
                    {
                        cin.clear();
                        cin.ignore(80, '\n');
                        input = false;
                    }
                    else
                        input = true;
                }while(!input);
                if((roll1 + roll2) > 10 || roll2 < 0)
                {
                    input = false;
                }
                else
                    input = true;
            }while(!input);
        }
        else
            roll2 = throw2;
        if (roll1 + roll2 < 10)
        {
            frameS = roll1 + roll2;
            throw1 = -1;
            throw2 = -1;
            return(frameS);
        }
        else if(roll1 + roll2 == 10)
        {
            do
            {
                do //this code block checks if the input is a number
                {
                    inFile >> roll3;
                    if(cin.fail())
                    {
                        cin.clear();
                        cin.ignore(80, '\n');
                        input = false;
                    }
                    else
                        input = true;
                }while(!input);
                if(roll3 > 10 || roll3 < 0)
                {
                    cout << "That is invalid. Please re-enter.";
                }
                else
                    input = true;
            }while(!input);
            
            frameS = roll1 + roll2 + roll3;
            throw1 = roll3;
            throw2 = -1;
            return frameS;
        }
    }
    
    else if(roll1 == 10)
    {
        if(throw2 == -1)
        {
            do
            {
                do //this code block checks if the input is a number
                {
                    inFile >> roll2;
                    if(cin.fail())
                    {
                        cin.clear();
                        cin.ignore(80, '\n');
                        input = false;
                    }
                    else
                        input = true;
                }while(!input);
                if(roll2 > 10 || roll2 < 0)
                {
                    input = false;
                }
                else
                    input = true;
            }while(!input);
        }
        else
            roll2 = throw2;
        if(roll2 < 10)
        {
            do
            {
                do //this code block checks if the input is a number
                {
                    inFile >> roll3;
                    if(cin.fail())
                    {
                        cin.clear();
                        cin.ignore(80, '\n');
                        input = false;
                    }
                    else
                        input = true;
                }while(!input);
                if(roll2 + roll3 > 10 || roll3 < 0)
                {
                    input = false;
                }
                else
                    input = true;
            }while(!input);
            
            if(roll2 + roll3 < 10)
            {
                frameS = roll1 + roll2 + roll3;
                throw1 = roll2;
                throw2 = roll3;
                return frameS;
            }
            else if(roll2 + roll3 == 10)
            {
                frameS = roll1 + roll2 + roll3;
                throw1 = roll2;
                throw2 = roll3;
                return frameS;
            }
        }
        else if(roll2 == 10)
        {
            do
            {
                do //this code block checks if the input is a number
                {
                    inFile >> roll3;
                    if(cin.fail())
                    {
                        cin.clear();
                        cin.ignore(80, '\n');
                        input = false;
                    }
                    else
                        input = true;
                }while(!input);
                if(roll3 > 10 || roll3 < 0)
                {
                    input = false;
                }
                else
                    input = true;
            }while(!input);
            
            if(roll3 < 10)
            {
                frameS = roll1 + roll2 + roll3;
                throw1 = roll2;
                throw2 = roll3;
                return frameS;
            }
            else if (roll3 == 10)
            {
                frameS = roll1 + roll2 + roll3;
                throw1 = roll2;
                throw2 = roll3;
                return frameS;
            }
        }
    }
}

//this function outputs the contents of the multidimensional array to an output file. it does not output a score if it is -1

void outputToFile(ofstream& outFile, int scoreCard[][10])
{
    if(outFile.is_open())
    {
        for(int g = 0; g < MAX_PLAYERS; g++)
        {
            outFile << "Player " << g+1 << " ";
            for(int h = 0; h < MAX_GAMES; h++)
            {
                if(scoreCard[g][h] != -1 && scoreCard[g][h] >= 0 && scoreCard[g][h] <= 300)
                    outFile << "Game " << h+1 << ": " << scoreCard[g][h] << " ";
            }
            outFile << endl;
        }
        
        cout << "********** Output process was successful **********" << endl << endl;
        outFile.close();
    }
    else
        cout << "********** Output process was unsuccessful. There is no open output file. **********" << endl << endl;
}
//this function outputs the contents of the multidimensional array to the screen. it does not output a score if it is -1

void outputToScreen(int scoreCard[][10])
{
    for(int g = 0; g < MAX_PLAYERS; g++)
    {
        cout << "Player " << g+1 << " ";
        for(int h = 0; h < MAX_GAMES; h++)
        {
            if(scoreCard[g][h] != -1 && scoreCard[g][h] >= 0 && scoreCard[g][h] <= 300)
                cout << "Game " << h+1 << ": " << scoreCard[g][h] << " ";
        }
        cout << endl;
    }
    
    cout << "********** Output process was successful **********" << endl << endl;
}


















